# When the Neutrinos Leave, version 5 — code, proofs and run logs

Jeromie Beasley. Paper text CC BY 4.0; code and Lean proofs MIT (LICENSING.md).

* `paper/neutrinos_leave_v5.tex` — the paper source; `paper/figs/`, `paper/code/`, `paper/results/` — every script, output and run log the PDF prints (Appendix B).
* `paper/code/v4_runs/` — the flux–shear link runs: `PREREGISTERED_V4.txt` (every prediction and kill line, written before each run, results appended), `ms_nuc_split.py` and `ms_nuc_shear.py` (S. McCormick's `ms_nuc.py` with one change each), the runners and search drivers (`*_v2.py`: horizon-only bracket rule, positivity monitor), all `log_*.txt` and `res_*.json`, and `ruler/` (the intrinsic-ruler check).
* `lean/` — the Lean 4 / Mathlib v4.34.1 project: 100 theorems, 12 false controls; `scripts/verify.py` runs the axiom audit. Green at commit c372d3f of github.com/dicipler-pixel/neutrinos-leave-lean.
* `upstream/` — McCormick's MIT licence and the commit of `quasilocal/PBH_neutrino_simulation` (archived as doi:10.5281/zenodo.23808376) the runs used. Clone it and set `SIMDIR=/path/to/PBH_neutrino_simulation/simulation`; `numba` is required.

To rerun a search: `SIMDIR=... bash paper/code/v4_runs/queue_F.sh` (and likewise for the other queue files). To rerun the ruler check: `python3 paper/code/v4_runs/ruler/ruler_state.py` (no simulation needed).
