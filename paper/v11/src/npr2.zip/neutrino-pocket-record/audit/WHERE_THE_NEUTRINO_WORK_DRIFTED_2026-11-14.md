# Where the neutrino work drifted from Jeromie's frame
Research Knowledge Curator, 14 November 2026. Audit only: nothing in any paper has been changed.

## Sources read in full for this audit
- *What the Neutrino State Must Keep* v10: `neutrinos_v10.tex`, `sec_new_gramian.tex`, `sec_new_door.tex`, `sec_new_mcc.tex`, `app_new_proofs.tex`.
  - Location: GitHub `neutrinos-leave-lean`, branch `claude/v6-what-the-state-must-keep`, commit 2a6aa3b.
- Ruler pre-registration and script: `code/v4_runs/ruler/PREREGISTERED_RULER.txt` and `ruler_state.py`.
- `Neutrino_Memory_Full_Paper_Plan.html`, 11 Nov. This is the blueprint the v6 to v10 chat followed. It is written about "Beasley" in the third person.
- `HANDOFF_NOTES_20261110_v1.md` (the "vacuum-disk rethink"). These are Jeromie's rules: §0 "IQGT is the frame", and §2, the 17 places where mainstream thinking creeps in.
- `NOTES_SM_IN_THE_BALL_20261111_v3.md`.
- *The Relational Atlas* and *The Quiet Law* drafts, in the VOTKP v2.9 records: "the First Full Crossing… Not a Big Bang of energy".
- Jeromie's statement of 14 Nov: "a self recurring transport system, a closed but growing system that eventually grows to a full relaxation then starts again; light leaves the lightest trail, all else follows and carves."

---

## A. The plan put McCormick's frame in charge and made Jeromie's frame decoration
All quotations below are word for word from `Neutrino_Memory_Full_Paper_Plan.html`. Each is followed by the rule it breaks.

1. **"In this paper, the time variable is the stated GR/conformal evolution parameter; no emergence-of-time claim is required."**
   - This sets aside Dirac Time ("begins from memory, not from a metric, a clock…").
   - It makes the imported clock the frame.
   - Breaks HANDOFF §0 and §2.14.
2. **"The Ball … is a visualization of specified observables, not an extra dynamical law."**
   - This demotes the Ball and the tree before any test was run.
3. **"VOTKP and the tree: contribute the discipline of explicit transitions … A shared drawing does not identify it with an elemental norm tree."**
   - This reduces VOTKP to a method of working.
4. **"Colour/SU(3), Koide and generation work … No dependence is introduced into this neutrino-collapse paper."**
   - This walls off NOTES_SM_IN_THE_BALL v3. Yet those notes found the neutrinos' top mass step on the Γ² = ½ wall, the same wall the neutrino paper's door sits at.
5. **"Building on McCormick's spherical GR transport calculation and Beasley's collision-link analysis…"** (the abstract scaffold)
   - This states whose frame is the host: McCormick's.
6. **"Engineered restarts establish possible sensitivity; a separate history-generated ensemble is needed to claim cosmological prevalence."**
   - This makes "history-generated" initial data the standard. In the Big Bang reading that means data whose hidden moments start empty.
   - The recurrence reading, in which hidden structure is carried over from the previous relaxation, is never posed.

## B. The setting of v10 is the standard cosmological timeline, taken unexamined
- §1: "Primordial black holes heavier than about 10⁶ M☉ form while the neutrinos … stop scattering."
- The time variable is ε = 1/(aHr_m), the Hubble radius. The clock is conformal τ.
- The words "big bang" never appear in v10. Even so, every run starts from an expanding radiation background with empty hidden moments at ε₀ = 0.1.
- §8 and the Summary end on: "whether cosmological initial data carry such structure at decoupling is a separate question, not answered here."
- In Jeromie's frame that is *the* question. A self-recurring system arrives at decoupling already carrying the hidden structure the previous cycle wrote. The door result shows the threshold reads it: up to 5.5×10⁻³, which is 11% of the whole free-streaming shift.

## C. The one test of the intrinsic frame fell back to a single vector
This is the most consequential drift.
- **The plan was IQGT-correct.**
  - The ruler pre-registration (5 Nov) planned the IQGT reading properly: the Riesz projector Π_r of the least-damped mode, the arc length of the pullback metric g_rr = ½‖dΠ/dr‖², rank 1 and rank 2.
  - It also included Jeromie's own trace form q(V) = ½ Re Tr V², "may be ≤ 0".
- **The projector reading was dropped at the wall.** At the readout rate κ = 0.958 the kept mode exists only for k < κπ/2. That covers about half the profile weight; past the onset wall κ = 2k/π, "there is no isolated kept eigenvalue".
- **The verdict rests on a single-vector reading.** v10 gives its verdict on ruler (e) (`ruler_state.py`): the principal angle between two *state vectors* v_r(τ*) and v₁(τ*).
- **v10's conclusion.** "Of the rulers tested, the law lives in the operator's link rapidity, and not in the displacement of the linear kept state."
- **The rules this breaks:**
  - HANDOFF §0: "read through the projector, never through single eigenvectors".
  - §2.16: "Any outside method that tracks one eigenvector … breaks the tail/tip rule".
  - §2.7: "His contribution is exactly where that [immersion] fails."
- **What it means.** Where the projector stopped existing, at the wall, the frame was set aside, when the wall is exactly where Jeromie's frame does its work:
  - fold and polar strata (IQGT Prop 8.6);
  - tip and tail held by different gaps (IQGT 10.2, 12.1);
  - the trace form q going negative (B57);
  - the Jordan block at the wall (atlas B177, B199).
- **Conclusion.** The intrinsic frame was not tested at the wall. A single-vector stand-in was, and v10 reports the frame as the loser.

## D. What stands regardless of framing (keep in full)
These are local transport statements and do not depend on a Big Bang:
- the cut identity (all non-normality on the density–flux link, 8⁻¹‖[L,L*]‖² = κ²k²/3, split form, √E_B = k/√3);
- the onset wall κ = 2k/π with non-orthogonality 4φ²/sin²2φ;
- the exact block elimination and the speed limit Ȧ² ≤ 4E_B A(1−A);
- the readout Gramian has no kernel;
- order matters at fixed opacity and fixed integrated connection energy;
- the door in the full collapse;
- the Lean results.

McCormick's runs are measurements in his setting. They stay labelled as his setting.

## E. How Jeromie's picture lines up with results already in v10
These pairings are readings, not yet tested claims.

| Jeromie's picture | Already in v10 |
|---|---|
| full relaxation | the coupled era: everything but the kept ℓ = 0 sector damped; the door shut (10⁻⁷ Gramian, 2×10⁻⁵ threshold) |
| starts again | the onset wall κ = 2k/π: the kept mode meets the continuum and streaming takes over |
| light leaves the lightest trail | the light-speed front versus the kept sector's sound speed √E_B = k/√3 |
| all else follows and carves | the door: what streamed returns into density and stress, and the threshold reads it with its sign set by parity and its size ranked by the Gramian |
| the record carries over | planted hidden structure at decoupling moves the threshold 200+ bracket widths; order is part of the record (§ Gramian) |

## F. Proposed next steps (each needs Jeromie's approval)
1. **A core page in Jeromie's own words**, read first by every session:
   - his frame;
   - the self-recurring system;
   - what he does not accept (the Big Bang setting; imported metrics and clocks).
   - He writes it, or approves a draft built only from his quoted words.
2. **Redo the wall test properly.** Run the ruler past the onset using his tools: the trace form q (sign recorded), rank-2 Riesz projectors held by a gap, the tip/tail split, and the fold/polar strata. Pre-register it first.
3. **Pose the recurrence question as a test.** Plant Gramian-ranked hidden structure at decoupling at amplitudes a relaxed previous cycle would leave, rather than engineered half-margin amplitudes. Then ask whether the threshold, and through it the mass function, carries the sign.
4. **A re-centred paper.** Keep every v10 result in full. Make Jeromie's frame the host and McCormick's runs the labelled setting. Answer the open question in the recurrence reading. Prior work (Penrose CCC, Steinhardt–Turok) is to be cited and distinguished.
