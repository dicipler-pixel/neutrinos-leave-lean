# The Neutrinos at the Wall — the pocket record

**Jeromie N. Beasley** · research log and working code, 14–15 November 2026
*AI-assisted: the ideas and direction are the author's; AI tools (Claude, Anthropic) were used for computation, code, drafting and typesetting. Every number below comes from a script in this repository.*

## The question

If the universe did not start from a Big Bang but recurs (relaxes fully, passes through a fold, and is reborn hot), then what can a neutrino carry from one cycle into the next?

## The answer so far, in the author's picture

1. **The fire tornado** is the hot rebirth: collisions scramble everything they touch.
2. **The ditch** is a quantity collisions cannot change. A neutrino's *direction* is not in a ditch: collisions act on it directly, and its record is erased (survival about 10⁻¹⁴⁵ from 10 MeV). A *flavour asymmetry* is in a ditch: collisions are flavour-blind and conserve it. This is the author's offset μ, the chemical potential.
3. **The electron cover** is the thermal potential of the electron sea. It blocks flavour oscillation, the only thing that could change the record.
4. **Heating the electron makes the ditch safer.** The leak goes like fire ÷ cover². In the deep heat the cover outgrows the fire, so survival stops depending on how hot it got (24% at cover ×1, 63% at ×10, 87% at ×100, from any start above about 10 MeV).
5. **The danger is the cover thinning,** in a window of about 2–6 MeV. What survives it freezes into the free-streaming neutrinos at the 1 MeV wall. It can be measured through the helium abundance and N_eff.

The general mechanism underneath is **a pocket sealed by a busy layer.** Its leak rate falls as 1/σ: the hotter the surrounding layer, the tighter the seal. The formula k²(c²+c²)/σ matches the simulation to four digits. **A cut, or two opposite-sign couplings, leaves an exactly protected pocket.** In random networks a single cut creates one 15.5% of the time (6 nodes), and an opposite-sign pair always gives one.

## What is in here

| Folder | What it holds |
|---|---|
| `paper/` | *The Neutrinos at the Wall*, draft 1 (13 pp, tex and pdf); `wall_checks.py` with its output (the wall theorem, masses on the wall, onset, abundance, fold) |
| `experiments/pockets/` | Nine experiments, A, B and D–J (there is no C: the label was skipped when the runs were set up, and nothing was removed): pocket census, Zeno sealing, McCormick flux sealing, rebirth erasure, fold passage, the parity test (refuted), cut networks, the energy-spectrum pocket, the heated electron cover |
| `experiments/abundance/` | Black-hole abundance from the measured door shifts (v11 physics section) |
| `experiments/momentum/` | Momentum closes the valley: V = ½x²y² has flat valleys yet a gap of 0.6333 (Simon 1983) |
| `cards/` | 3D cards N1 (the wall), N2 (the fold), N3 (momentum closes the valley; Mona Tesla art grammar), all forward-only; plus their sources |
| `records/` | The author's answers word for word, outline v0, black-hole read record |
| `audit/` | Where the earlier neutrino work drifted from the author's frame |
| `acc_side/` | ACC search tools from the same days (library, sonar, chum, hatch, tree beam). They need the public SAIR verifier checkout (set `ACC_MANIFEST` to its `manifest.json`) and a folder of road files (`ACC_ROADS_DIR`); neither is included. |
| `LOG.md` | Everything done, in order, with results and corrections. This is the real timeline: the git commits were made together when the package was assembled on 15 Nov, so their timestamps are packaging times, not work times. |

## Prior work credited

- Boyle, Finn & Turok (2018): the CPT-mirror continuation, and a massless lightest neutrino.
- Alikhanov (2026): the mass relation m₃/m₂ = 3+2√2.
- McCormick (2026): the collapse code and the free-streaming effect.
- Dolgov et al. (2002): flavour equilibration of neutrino asymmetries.
- B. Simon (1983) and Lüscher (1983): discrete spectra in flat-valley potentials.
- Romatschke (2016): the kinetic onset 2k/π.

## Status

- Exploratory, with toy models where stated.
- The flavour-cover result is a two-flavour averaged model, not a full quantum kinetic calculation.
- Nothing here claims the Yang–Mills mass gap or a proof of a cyclic universe.

Licence: code MIT, text CC BY 4.0.
