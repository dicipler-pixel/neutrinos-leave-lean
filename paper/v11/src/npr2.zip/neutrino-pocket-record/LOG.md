# Log — 14–15 November 2026

Each entry gives what was asked, what was done, the result, and any correction. Every number comes from the script named.

## 14 Nov — the neutrino paper read and audited
- Read *When the Neutrinos Leave* v3.1, then v10 (*What the Neutrino State Must Keep*, branch `claude/v6-what-the-state-must-keep`, commit 2a6aa3b) in full: all sections, proofs A.1–A.15, and the Lean list.
- Re-ran its identity and memory-curve checks: both reproduce exactly. All G values recompute.
- **Audit** (`audit/WHERE_THE_NEUTRINO_WORK_DRIFTED_2026-11-14.md`):
  - The 11 Nov plan subordinated the author's frame to McCormick's setting.
  - v10's one test of the intrinsic frame fell back to single state vectors at the wall, where the projector stopped existing.
  - So the frame was never tested at the wall.

## 14 Nov — the physics the paper was missing
- **Black-hole abundance from the measured door shifts** (`experiments/abundance/abundance.py`): the number of black holes changes by 10–47%, with the sign set by the record's orientation. A random orientation still gives +1–8%.
- **Correction:** an earlier chat figure (up to −53%) used pair differences instead of shifts from the unperturbed run. It is withdrawn.
- **v11 physics section** written (`sec_physics.tex`): abundance, mechanism reading, mass range, a universe without a first moment, the neutrinos on the wall.

## 14 Nov — *The Neutrinos at the Wall*, draft 1 (`paper/`)
- **The wall theorem:** tr K = 2 − 4 sinh⁴(r/2) is parabolic at r = ln(3+2√2), Γ² = ½. Checked numerically at four rapidities.
- **Masses on the wall:**
  - the neutrino step m₃/m₂ = 5.8165 ± 0.079 is −0.15σ from the wall;
  - charged-fermion steps all lie past it;
  - predictions: normal ordering, m₁ ≲ 2 meV, Σm = 59.1 meV, Δm²₃₁/Δm²₂₁ = 33.97, m_β = 8.85 meV, m_ββ = 1.5–3.7 meV.
- **Decoupling wall:** κ = 2k/π, where K = 4φ²/sin²2φ diverges.
- **The radiation era as a fold:** a = η odd, t = η²/2 even.
- **Prior art found and credited:**
  - Boyle–Finn–Turok predicted m₁ = 0 from CPT symmetry.
  - Alikhanov has the mass relation.
- **Black-hole work read in full** (`records/READ_RECORD_BLACK_HOLE_WORK_2026-11-14.md`): edition 10, proof log v7, v2, the dynamo scripts.

## 15 Nov — cards (`cards/`)
- **N1 (the wall), N2 (the fold):** v2 is forward-only with solid, lit 3D, at the author's request.
- **N3 (momentum closes the valley),** in the Mona Tesla art grammar:
  - epicycle outlines of |ψ₀|²;
  - tone, grain and Perron colour on the landscape;
  - fracture-envelope lightning along the valleys.

## 15 Nov — the missing ingredient is momentum (`experiments/momentum/`)
- **Result:** H = ½(p²) + ½x²y² has classically flat valleys, yet a discrete spectrum with gap 0.6333. This converged on three grids (box ±10, ±14, ±18).
- **Why:** the sideways zero-point cost |s|/2 closes each valley (Simon 1983).
- **Links to the author's own work:**
  - F_Q = 8K (*Beyond the Event Horizon*) makes the IQGT metric the kinetic side;
  - the Casimir term in the Yang–Mills certificates is that momentum.

## 15 Nov — how neutrinos are reborn, and what survives (`experiments/pockets/`)
- **Rebirth is thermal:** any phase hotter than about 1 MeV remakes neutrinos (Γ/H ≈ (T/1 MeV)³). Candidate heat sources: flux-string breaking (Schwinger/Lund) and the fold's rip (Parker; Boyle–Finn–Turok).
- **B (rebirth):** a directly damped record is erased (survival about 10⁻¹⁴⁵ from 10 MeV).
- **Correction:** the draft-1 prediction of a carried *angular* record does not survive standard physics. It is to be replaced.
- **A (census):** the neutrino chain has no exact pocket under single-rate, split or McCormick collisions; every undamped moment leaks to a damped neighbour.
- **E (Zeno):** a pocket inside a busy layer leaks at k²(c²+c²)/σ. This matches to four digits; the hotter the layer, the better the seal.
- **F:** strong self-scattering seals the flux pocket in McCormick's model. The slowest decay falls from 0.118 to 0.0113 as κ_n goes from 1 to 100.
- **D (fold passage):** a hot fold erases the record; a cold fold passes 1–5% back and up to 13% into the kept sector.
- **G (parity test):** across many patterns and wave sizes there is no consistent even/odd rule, so D's hint was an accident.
- **I (cuts):** one cut creates an exactly protected mode in 15.5% of 6-node, 4.8% of 8-node and 1.4% of 10-node random networks. Opposite-sign couplings always give one.
- **B, second part (Zeno-sealed pocket):** the first saved output ended in a crash (`np.trapz` is gone from new numpy). Fixed to `np.trapezoid` and rerun: survival 0.967, 0.948, 0.942 and 0.936 from 2, 5, 10 and 100 MeV.
- **H (energy spectrum):** elastic scattering never erases a spectral distortion. Survival is set by the inelastic share and the starting temperature (e.g. 98% from 2 MeV, 55% from 5 MeV at an inelastic share of 0.001).
  - **Correction:** the script's last printed line says survival does not depend on heat. The table shows it does.
- **J (heated electron cover):**
  - the flavour record is protected by the thermal potential;
  - survival is 24%, 63% and 87% at cover ×1, ×10 and ×100, independent of starting temperature above about 10 MeV;
  - the leak window is about 2–6 MeV;
  - a hotter fire with the same cover gives 0%.
  - **Limit:** two-flavour averaged toy model.

## Side work, same days (`acc_side/`)
- ACC rows sac-00989 and ac-07337: no new record.
- Methods: local window search, a 4,052-road symmetric library, sonar (commutator collapse at the wall marks the "done" point of every road, at 85% on average), chum, hatch.
- Recorded honestly as negative.

## Open, next
1. A full quantum-kinetic flavour run through the 2–6 MeV window.
2. The spectral pocket in McCormick's six-group model.
3. A search for an exact opposite-sign pocket in the flavour operator.
4. *The Neutrinos at the Wall*, draft 2: replace the angular-record prediction with the flavour-asymmetry and spectral record.

## 15 Nov (later) — independent review before publishing
- Three reviewers re-ran every script on byte-identical copies. The paper checks, A, D–J, the abundance script and the momentum gap 0.6333 all reproduce exactly.
- Fixes made:
  - B's stale crash output was rerun;
  - machine-specific `/tmp` paths were replaced with environment variables (`ACC_MANIFEST`, `ACC_ROADS_DIR`) and a plain `require('playwright')`;
  - the missing experiment C is explained;
  - commit timestamps are stated to be packaging times;
  - the file count is corrected.
