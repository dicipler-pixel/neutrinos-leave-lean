# Publishing this as a new GitHub repository
1. On github.com click **New repository**, name it `neutrino-pocket-record`, leave it empty (no README), create.
2. In a terminal inside this folder:
```
git remote add origin https://github.com/dicipler-pixel/neutrino-pocket-record.git
git push -u origin main
```
That uploads the full history (every commit below). Or use GitHub Desktop: File → Add local repository → this folder → Publish.
