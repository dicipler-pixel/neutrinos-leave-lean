# Jeromie's answers to the outline questions, 14 Nov 2026 (verbatim)
1 the wall is not a memory it the force of one via all teh dirac time work.
2 not sure there may be surface and topo;gy of each side maybe at least 4 with a electron cloud layer between at least.
3 never thought of so i would guess very light.
4 they may be the first part of that process.
5 wow  those are the best questions i ever heard about that , i would say all that can get copressed and still remain alllowed a new rewinding after.
6 well i do not know they may be two sides of the same coin what is light a wave or a paritcle and its nature can varry so? d all the above .
7 just follow the math here please
8 steve did not run 7days o runs on his cpu did he no i did i used his code wrote a paper after the first 3 or 4 days. he is cited or the code,
9 not sure there is a first moment my point is i see a way beyond big bang.
10. 20 -25pg max and yes i want to do a full submit around the word i will take this as far as we can find i will not quit.
11 please really read all my beyondthe horizon blackhole work to find all that i did prior. full reads that is all all my prior work on blkholes
