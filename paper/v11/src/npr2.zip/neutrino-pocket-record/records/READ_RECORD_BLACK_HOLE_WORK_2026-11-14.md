# Read record: Jeromie's black-hole work, read in full for *The Neutrinos at the Wall*
Curator, 14 Nov 2026. Written once so later sessions do not need to re-read the sources.

## What was read
- **Read in full**
  - *Beyond the Event Horizon: What Survives at a Rigidity Wall*, research edition 10/10.1 (20 Oct 2026). Source: `bh_v10_1_hexagon_source.zip::bh_paper_v10.tex`, all 1,110 lines: abstract, §§1–11, Appendices A–B, bibliography.
  - *Beyond the Event Horizon*, v2 final (Aug 2026), the text in full (the printed scripts appendix was skimmed).
  - Combined Penrose–Beasley comparison (12 Oct). This concerns the OpenAI spacetime Penrose-inequality manuscript, not Penrose's cyclic cosmology.
- **Read to the depth stated**
  - Edition 8.5.1: section headings compared with edition 10. The only difference is that edition 10 adds "Reflection and refraction on the pullback metric". Nothing in 8.5.1 was dropped from 10.
  - event-horizon-lean README (40 theorems, including the edition-10 additions).
- **Not read**
  - the v8.5 proof log v7 (37k);
  - the bh_dynamo scripts in Suns v1.5;
  - the November HTML copy of edition 10 (same text as the source; its title says "Research edition 10").

## His black-hole results, in his own terms (all from edition 10)
1. **The wall is a fold.**
   - The coplanar wall w₃ = 0 is at finite distance, arcsin√ε, when read in the signed coordinate σ₃ = sign(det X)·√w₃.
   - The Gram observer, who uses the even quantity w₃ = σ₃², sees a bounce and a 1/w₃ blow-up. In the signed coordinate the path passes through to the mirror configuration.
2. **Two exact readings at the wall.**
   - The transport A = P_W D_T P_W is self-adjoint in the kinetic (Bures) metric.
   - In the Gram frame the back-coupling A₂₁ ∝ σ₃² → 0: one-way. "What happens in the wall cannot write back across it, while what arrives across the wall is written into it." Under a joint condition it forms a Jordan block.
   - On the oriented cover it is a plain double point at the tip of a cone.
3. **Two survival principles.**
   - "The contour keeps the ledger": the pair projector and log det(c + A_pair) stay exact through the wall.
   - "The orientation keeps the trace": a Z₂ record survives, as the sign of det X and the analytic branch label.
   - Odd readings cancel across the mirror; even readings survive.
4. **Two kinds of wall.**
   - Spectral walls: a real pair turns complex, and the Jordan block appears in every frame. Examples: the Sun's dynamo, the optical threshold, the innermost stable circular orbit (ISCO) at 6M, ringdown exceptional points.
   - Geometric walls: the spectrum stays real on both sides. Examples: the coplanar fold, the static base of a horizon.
   - "A black hole carries one of each."
5. **ISCO.** The effective power of gravity, p = 2 + 6M/r, reaches the inverse cube at the ISCO. The photon ring has growth rate equal to orbital rate, so each extra half orbit dims an image by e^(−π).
6. **The horizon is a matched load.**
   - Surface resistance = vacuum impedance, so Z_b = 1 and S_b = 0: the horizon returns nothing.
   - On the Smith chart it sits at the centre.
7. **The fermion record.**
   - The outside half of a fermion Hawking pair has offset τ = ħω/k_BT_H for every pair phase, so Γ = tanh(ħω/2k_BT_H).
   - It reaches the chart centre only at ω = 0. Particle–hole exchange gives Γ → −Γ.
   - This holds for fermions only: bosons have no "full" state.
8. **Hair as boundary compression.**
   - D(X) = PXP keeps the cluster's trace and ledger: "rank compression, not destruction."
   - Retention model: with any return channel (b > 0) everything eventually comes back. With b = 0 a fraction stays forever. The limits t → ∞ and b → 0 do not commute: delay is not trapping.
9. **Bell at the horizon.**
   - The outside record is thermal and blind to the pair's phase, yet that phase decides the pair's future.
   - The one-way books balance only with Hawking's flux.
10. **Reflection at a step of the projector metric.**
    - Γ = tanh(½ ln Δ₂/Δ₁), with g⊥ dropping out.
    - Total reflection begins exactly at the Clairaut turning point.
11. **The fold normal form ds² = dX²/(4c²X)** is shared by the four-body wall (c = 1) and the Schwarzschild static base (c = κ). The extremal case has no fold.

## What this gives the neutrino paper (curator's mapping; for Jeromie's approval)
- **His answer 1: "the wall is the force of a memory."**
  - Item 2 states it exactly: at the wall, what arrives is written in and nothing writes back.
  - The wall exerts the one-way pull of the record. It is not itself the stored record.
- **His answer 2: "surface and topology of each side, maybe 4, with an electron cloud layer between."**
  - The neutrinos decouple from the e± plasma at about 1 MeV. The e± then annihilate at about 0.5 MeV and heat the photons, not the neutrinos.
  - So between the neutrino side and the photon side there is literally an electron–positron layer. *(Standard physics, cited.)*
  - The four-body shape space, whose fold has two sheets, is his own setting.
  - SCREEN-PROG is the electron cloud at a barrier in the laboratory.
- **His answer 4: neutrinos are "the first part of the process."**
  - Neutrinos let go first (about 1 MeV), long before photons (about 0.26 eV).
  - They are the first species to cross the decoupling wall: the first conversion.
- **His answer 5: "all that can get compressed and still remain allowed a new rewinding after."**
  - This is item 8 (compression keeps trace and ledger) combined with item 1 (the fold passes to the mirror).
  - A cycle's end is a fold. The Gram (density-only) observer sees a bounce or singularity. In the signed coordinate the path passes through to the mirror. What crosses is what compression keeps: the ledger (even) and the orientation (the Z₂ sign).
- **His answer 6: light as "two sides of the same coin."**
  - Item 7: the fermion (neutrino) record has an offset τ = ħω/kT and a Smith point. The boson (photon) pair has no "full" state.
  - Photons and neutrinos are the boson and fermion sides of the same thermal record.
- **His answer 9: "a way beyond the Big Bang."** This is his fold theorem (items 1 and 11) applied to the radiation era:
  - in the radiation era a ∝ η (conformal time) and a² ∝ t;
  - so cosmic time t is the even quantity, the scale factor a (or η) is the signed one, and continuing η → −η reaches the mirror.

## Prior art found (web-checked 14 Nov 2026) — must be cited
**Boyle, Finn & Turok, *CPT-Symmetric Universe*, PRL 121, 251301 (2018), arXiv:1803.08928; companion arXiv:1803.08930 (Ann. Phys. 2022).**
- The universe after the bang is the CPT image of the one before it; a(τ) is odd in conformal time. This is the same structure as Jeromie's fold read cosmologically.
- They predict that the light neutrinos are Majorana, that **the lightest neutrino is massless**, and that there are no primordial long-wavelength gravitational waves.
- Consequences:
  - Jeromie's m₁ ≈ 0 coincides with their prediction. His fold theorem arrived at the same continuation independently, from four-body shape space.
  - What is distinctively his:
    1. recurrence, not a single universe/anti-universe pair;
    2. the record surviving the fold (ledger even, orientation Z₂);
    3. the neutrino hidden record and the door into black holes;
    4. the heaviest mass step on the wall Γ² = ½, which fixes m₃/m₂ = 3+2√2 (Boyle–Finn–Turok do not fix the ratio; Alikhanov 2026 has the number).
- Also to cite: Penrose's conformal cyclic cosmology (CCC); Steinhardt–Turok cyclic model.
