import os
import json,sys,time
from common import *
def bfs(src,R,cap,stop=None):
    D={src:0}; fr=[src]
    for d in range(1,R+1):
        nf=[]
        for s in fr:
            for m in range(14):
                t=move(s,m)
                if t in D or len(t[0])+len(t[1])>cap: continue
                D[t]=d; nf.append(t)
        fr=nf
        if stop and len(D)>stop: break
    return D
def build_table(S,RB,cap,nb=3):
    L=len(S)-1; t0=time.time()
    T=bfs(('x','y'),RB,cap)               # exact distance to target (moves invertible, inverse set = same set)
    print(f"  target ball r={RB}: {len(T)} states, {time.time()-t0:.0f}s",flush=True)
    for j,s in enumerate(S):              # road neighbourhoods: upper bound to end
        for t,e in bfs(s,nb,cap).items():
            v=(L-j)+e
            if v<T.get(t,1e9): T[t]=v
    return T
def path_to(src,dst,R,cap):              # recover a move sequence src->dst by BFS with parents
    P={src:None}; fr=[src]
    for d in range(R):
        nf=[]
        for s in fr:
            for m in range(14):
                t=move(s,m)
                if t in P or len(t[0])+len(t[1])>cap: continue
                P[t]=(s,m); nf.append(t)
                if t==dst:
                    seq=[];x=t
                    while P[x]: x,mm=P[x]; seq.append(mm)
                    return seq[::-1]
        fr=nf
    return None
def finish(s,T,cap):                     # greedy descend T to target, using exact neighbours
    seq=[]
    while s!=('x','y'):
        best=None
        for m in range(14):
            t=move(s,m)
            if t in T and T[t]<T[s] and (best is None or T[t]<T[best[0]]): best=(t,m)
        if best is None: return None
        s,m=best; seq.append(m)
    return seq
if __name__=="__main__":
    row=sys.argv[1]; RB=int(sys.argv[2]); RF=int(sys.argv[3]); capx=int(sys.argv[4])
    d=json.load(open('rows.json'))[row]; start=tuple(d['start']); road=d['road']
    while True:
        S=run(start,road); L=len(road); cap=max(len(a)+len(b) for a,b in S)+capx
        print(f"{row}: road {L}, cap {cap}",flush=True)
        T=build_table(S,RB,cap)
        best=(L,None)
        for i in range(L):
            F=bfs(S[i],RF,cap,stop=3_000_000)
            for s,dd in F.items():
                v=T.get(s)
                if v is not None and i+dd+v<best[0]: best=(i+dd+v,(i,s,dd))
            if best[1]: print(f"   i={i}: best {best[0]}",flush=True)
        if not best[1]: print("no improvement");break
        i,s,dd=best[1]; mid=path_to(S[i],s,dd,cap)
        # tail: if s on table via road neighbourhood or ball; rebuild by finishing through T greedily (T monotone along true paths in ball; for road nbhd use path to road state)
        tail=finish(s,T,cap)
        if tail is None:
            # route to nearest road state then follow road
            for j in range(L,-1,-1):
                p=path_to(s,S[j],3,cap)
                if p is not None and i+dd+len(p)+(L-j)==best[0]: tail=p+road[j:];break
        new=road[:i]+mid+tail
        assert run(start,new)[-1]==('x','y'); print(f"  NEW ROAD {len(new)}: {new}",flush=True)
        road=new; json.dump(new,open(f'best_{row}.json','w'))
