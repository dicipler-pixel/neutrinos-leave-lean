import os
import json,sys,time
from common import *
from shorten import bfs
row,goal=sys.argv[1],int(sys.argv[2]); d=json.load(open('rows.json'))[row]
S=run(tuple(d['start']),d['road']); cap=max(len(a)+len(b) for a,b in S)+4
t0=time.time(); T=bfs(('x','y'),8,cap); print("T",len(T),f"{time.time()-t0:.0f}s",flush=True)
for i in [24,23,22,25,21]:
    R=min(8,goal-1-i-8)
    if R<1: continue
    F=bfs(S[i],R,cap)
    best=min((dd+T[s] for s,dd in F.items() if s in T),default=99)
    print(f"i={i} R={R} ball {len(F)} best to end {best} -> total {i+best} (need <{goal}) {time.time()-t0:.0f}s",flush=True)
    del F
