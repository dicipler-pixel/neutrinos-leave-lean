import os
import json,sys,time
from common import *
from shorten import bfs
row=sys.argv[1]; R=int(sys.argv[2]); capx=int(sys.argv[3]); minw=int(sys.argv[4])
d=json.load(open('rows.json'))[row]; start=tuple(d['start']); road=d['road']
S=run(start,road); L=len(road); cap=max(len(a)+len(b) for a,b in S)+capx
print(row,L,'cap',cap,flush=True); t0=time.time()
Bc={}
for i in range(0,L-minw+1):
    F=bfs(S[i],R,cap)
    for j in range(i+minw, min(L,i+2*R+1)+1):
        if j not in Bc: Bc[j]=bfs(S[j],R,cap)
        B=Bc[j]; small,big=(F,B) if len(F)<len(B) else (B,F)
        best=min((small[s]+big[s] for s in small if s in big),default=99)
        if best<j-i: print(f"SHORTCUT {i}->{j}: {best} < {j-i}",flush=True)
    for j in list(Bc):
        if j<=i+minw: del Bc[j]
    print(f" i={i} done {time.time()-t0:.0f}s, cached {len(Bc)}",flush=True)
