import os
# SCRIPT: ACC-REPLAY-RECORD-01  replay every library road; record per-step features; test which features track progress (steps-to-go)
import pickle,math,json,numpy as np
from common import *
lib=pickle.load(open('lib.pkl','rb'))
roads={}
for s,(r,rid,i,p) in lib.items(): roads.setdefault((rid,p),None)
m=json.load(open(os.environ.get('ACC_MANIFEST','Andrews-Curtis/competition/tools/verifier/data/manifest.json'))); C={c['challenge_id']:c for c in m['challenges']}
def mk(z):
    r=math.log(z); c,s=math.cosh(r/2),math.sinh(r/2); I=np.eye(2,dtype=complex)
    sx=np.array([[0,1],[1,0]],complex); sy=np.array([[0,-1j],[1j,0]])
    M={'x':c*I+s*sx,'X':c*I-s*sx,'y':c*I+s*sy,'Y':c*I-s*sy}
    def mat(w):
        A=I
        for ch in w: A=A@M[ch]
        return A
    def feats(st):
        A,B=mat(st[0]),mat(st[1])
        tr=abs(np.trace(A))+abs(np.trace(B))             # how "far out" (hyperbolic size)
        adj=lambda Q: np.array([[Q[1,1],-Q[0,1]],[-Q[1,0],Q[0,0]]]); K=A@B@adj(A)@adj(B)          # their commutator: turn vs run (his Pair reading)
        da=min(np.linalg.norm(A-g) for g in (M['x'],-M['x'],M['X'],-M['X'],M['y'],-M['y'],M['Y'],-M['Y']))
        db=min(np.linalg.norm(B-g) for g in (M['x'],-M['x'],M['X'],-M['X'],M['y'],-M['y'],M['Y'],-M['Y']))
        return math.log(tr), math.log1p(abs(np.trace(K).real)), math.log1p(da)+math.log1p(db)
    return feats
rows=[]
for z in [2.0,3.0,3+2*math.sqrt(2),5.0]:
    f=mk(z); agg={'len':[], 'logtr':[], 'commtr':[], 'tdist':[]}; up={'len':0,'tdist':0,'logtr':0}; climbs=0; n=0
    for (rid,p) in roads:
        S=run(tuple(enc(w) for w in C[rid]['initial_relators']),list(p)); L=len(p)
        if L<20: continue
        n+=1
        F=[f(s) for s in S]; ln=[len(a)+len(b) for a,b in S]; togo=[L-i for i in range(L+1)]
        for key,vals in [('len',ln),('logtr',[x[0] for x in F]),('commtr',[x[1] for x in F]),('tdist',[x[2] for x in F])]:
            agg[key].append(np.corrcoef(vals,togo)[0,1])
        # during climbs (length rising), does the tree measure still fall?
        for i in range(L):
            if ln[i+1]>ln[i]:
                climbs+=1
                if F[i+1][2]<F[i][2]: up['tdist']+=1
                if F[i+1][0]<F[i][0]: up['logtr']+=1
    print(f"z={z:.4f}: {n} roads >=20 moves | corr with steps-to-go: length {np.nanmean(agg['len']):+.3f}, log|tr| {np.nanmean(agg['logtr']):+.3f}, tree dist {np.nanmean(agg['tdist']):+.3f}, comm trace {np.nanmean(agg['commtr']):+.3f} | on {climbs} length-rising steps, tree dist still falls {up['tdist']/climbs:.1%}, log|tr| falls {up['logtr']/climbs:.1%}",flush=True)
