import os
import json,sys,time,random,math
import numpy as np
from common import *
from shorten import bfs
row,z,lam,K,cap,target,seed=sys.argv[1],float(sys.argv[2]),float(sys.argv[3]),int(sys.argv[4]),int(sys.argv[5]),int(sys.argv[6]),int(sys.argv[7])
random.seed(seed); r=math.log(z); c,s=math.cosh(r/2),math.sinh(r/2)
I2=np.eye(2,dtype=complex); sx=np.array([[0,1],[1,0]],complex); sy=np.array([[0,-1j],[1j,0]])
M={'x':c*I2+s*sx,'X':c*I2-s*sx,'y':c*I2+s*sy,'Y':c*I2-s*sy}
def mat(w):
    A=I2
    for ch in w: A=A@M[ch]
    return A
def tdist(st):   # how far the pair of rotations sits from the generators' own (projectively, sign-free)
    a,b=st; A,B=mat(a),mat(b)
    da=min(np.linalg.norm(A-M['x']),np.linalg.norm(A+M['x']),np.linalg.norm(A-M['X']),np.linalg.norm(A+M['X']))
    db=min(np.linalg.norm(B-M['y']),np.linalg.norm(B+M['y']),np.linalg.norm(B-M['Y']),np.linalg.norm(B+M['Y']))
    return math.log1p(da)+math.log1p(db)
d=json.load(open('rows.json'))[row]; start=tuple(d['start'])
T=bfs(('x','y'),7,cap); t0=time.time()
layers=[{start:None}]; fr=[start]; seen={start}
for depth in range(1,target):
    cand={}
    for st in fr:
        for m in range(14):
            t=move(st,m)
            if t in seen or t in cand or len(t[0])+len(t[1])>cap: continue
            cand[t]=(st,m)
    hit=[(T[t],t) for t in cand if t in T and depth+T[t]<target]
    if hit:
        v,t=min(hit); seq=[];x=t;L=layers+[cand];k=len(L)-1
        while L[k][x]: x,mm=L[k][x]; seq.append(mm); k-=1
        print(f"HIT {depth}+{v}={depth+v} prefix {seq[::-1]} state {t}",flush=True); break
    sc={t:(len(t[0])+len(t[1]))+lam*tdist(t)+random.random()*0.5 for t in cand}
    keys=sorted(cand,key=sc.get)[:K]
    layers.append({t:cand[t] for t in keys}); fr=keys; seen.update(keys)
    if depth%8==0: print(f" d{depth} minlen {min(len(t[0])+len(t[1]) for t in fr)} {time.time()-t0:.0f}s",flush=True)
print("end",flush=True)
