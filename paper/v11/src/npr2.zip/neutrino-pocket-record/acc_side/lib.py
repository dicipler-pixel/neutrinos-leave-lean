import os
import json,re,glob,os,sys,pickle
from common import *
m=json.load(open(os.environ.get('ACC_MANIFEST','Andrews-Curtis/competition/tools/verifier/data/manifest.json')))
C={c['challenge_id']:c for c in m['challenges']}
roads={}
pat=re.compile(r'(s?ac-\d{5})\D{0,40}?\[([\d,\s]+)\]')
files=glob.glob(os.path.join(os.environ.get('ACC_ROADS_DIR','roads'),'*'))+[]
for f in files:
    if os.path.getsize(f)>60e6: continue
    try: t=open(f,errors='ignore').read()
    except: continue
    for rid,mv in pat.findall(t):
        try: p=[int(x) for x in mv.split(',') if x.strip()]
        except: continue
        if rid.startswith('sac'):
            # strip trailing stable finish (destabilise ids >=14) to get an AC-like road on the same start
            while p and p[-1]>=14: p.pop()
            if any(x>=14 for x in p): continue
            rid=rid[1:]
        if rid in C and p and max(p)<14: roads.setdefault(rid,set()).add(tuple(p))
good=0; lib={}   # state -> (dist_to_xy, rid, idx, roadlen)
for rid,ps in roads.items():
    st=tuple(enc(w) for w in C[rid]['initial_relators'])
    for p in ps:
        S=run(st,list(p))
        # accept roads that end at (x,y) up to signs
        e=S[-1]
        if e!=('x','y'): continue
        good+=1; L=len(p)
        for i,s in enumerate(S):
            r=L-i
            if s not in lib or lib[s][0]>r: lib[s]=(r,rid,i,p)
print("rows",len(roads),"verified roads",good,"library states",len(lib))
pickle.dump(lib,open('lib.pkl','wb'))
