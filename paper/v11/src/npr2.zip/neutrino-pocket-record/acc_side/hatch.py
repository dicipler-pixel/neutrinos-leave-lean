import os
# SCRIPT: ACC-HATCH-01 transplant a sibling's road (same family, shifted exponent) onto the target and look for a finish
import json,sys,pickle
from common import *
from shorten import bfs
from sonar import trK
tgt,donor,goal=sys.argv[1],sys.argv[2],int(sys.argv[3])
lib=pickle.load(open('lib.pkl','rb')); P=min((p for s,(r,rid,i,p) in lib.items() if rid==donor),key=len)
start=tuple(json.load(open('rows.json'))[tgt]['start'])
T=bfs(('x','y'),7,45)
S=run(start,list(P)); best=99
for k,st in enumerate(S):
    L=len(st[0])+len(st[1]); F=bfs(st,5,max(45,L+4))
    hit=min((dd+T[s] for s,dd in F.items() if s in T),default=None)
    tag=f"total {k+hit}" if hit is not None else "-"
    print(f"k={k:2d} len {L:3d} wall-gap {abs(trK(st)+2):9.2e} {tag}",flush=True)
    if hit is not None: best=min(best,k+hit)
print("BEST",best,"need <",goal)
