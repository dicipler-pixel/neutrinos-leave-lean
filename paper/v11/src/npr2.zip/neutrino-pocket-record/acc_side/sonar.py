import os
# SCRIPT: ACC-SONAR-01 mark commutator-collapse positions on every library road (z = 3+2sqrt2, the wall)
import pickle,json,math,numpy as np
from common import *
z=3+2*math.sqrt(2); r=math.log(z); c,s=math.cosh(r/2),math.sinh(r/2); I=np.eye(2,dtype=complex)
sx=np.array([[0,1],[1,0]],complex); sy=np.array([[0,-1j],[1j,0]])
M={'x':c*I+s*sx,'X':c*I-s*sx,'y':c*I+s*sy,'Y':c*I-s*sy}
adj=lambda Q: np.array([[Q[1,1],-Q[0,1]],[-Q[1,0],Q[0,0]]])
def mat(w):
    A=I
    for ch in w: A=A@M[ch]
    return A
def trK(st):
    A,B=mat(st[0]),mat(st[1]); return np.trace(A@B@adj(A)@adj(B)).real
if __name__=="__main__":
    lib=pickle.load(open('lib.pkl','rb')); m=json.load(open(os.environ.get('ACC_MANIFEST','Andrews-Curtis/competition/tools/verifier/data/manifest.json'))); C={c['challenge_id']:c for c in m['challenges']}
    roads={(rid,p) for s,(r_,rid,i,p) in lib.items()}
    rem=[]; frac=[]; hooks={}; peaks=[]
    for rid,p in roads:
        S=run(tuple(enc(w) for w in C[rid]['initial_relators']),list(p)); L=len(p)
        k=next(i for i,st in enumerate(S) if abs(trK(st)+2)<1e-6)
        rem.append(L-k); frac.append(k/L)
        st=S[k]; v=L-k
        if st not in hooks or hooks[st]>v: hooks[st]=v
        peaks.append(max(len(a)+len(b) for a,b in S[k:]))
    rem=np.array(rem); print(f"{len(roads)} roads: collapse at {np.mean(frac):.0%} of the way on average; moves left after collapse: median {np.median(rem):.0f}, 90% <= {np.percentile(rem,90):.0f}, max {rem.max()}; max length after collapse median {np.median(peaks):.0f}")
    print("distinct collapse hooks:",len(hooks))
    pickle.dump(hooks,open('hooks.pkl','wb'))
