import os
# SCRIPT: ACC-CHUM-01 forward beam to ANY wall-collapse state (trK=-2), then exact clean-up via the goal ball
import json,sys,time,random,math,pickle
from common import *
from shorten import bfs, path_to
from sonar import trK
row,K,cap,goal,w,seed=sys.argv[1],int(sys.argv[2]),int(sys.argv[3]),int(sys.argv[4]),float(sys.argv[5]),int(sys.argv[6])
random.seed(seed); d=json.load(open('rows.json'))[row]; start=tuple(d['start'])
T=bfs(('x','y'),7,40); t0=time.time(); found=[]
layers=[{start:None}]; fr=[start]; seen={start}
for depth in range(1,goal):
    cand={}
    for st in fr:
        for m in range(14):
            t=move(st,m)
            if t in seen or t in cand or len(t[0])+len(t[1])>cap: continue
            cand[t]=(st,m)
    for t in cand:
        if abs(trK(t)+2)<1e-6:
            rest=T.get(t)
            if rest is None:
                D=bfs(t,min(10,goal-depth-1),max(40,len(t[0])+len(t[1])+4)); rest=min((dd+T[s] for s,dd in D.items() if s in T),default=None) if False else D.get(('x','y'))
            if rest is not None and depth+rest<goal:
                seq=[];x=t;L=layers+[cand];k=len(L)-1
                while L[k][x]: x,mm=L[k][x]; seq.append(mm); k-=1
                print(f"HOOKED depth {depth} + cleanup {rest} = {depth+rest}: prefix {seq[::-1]} state {t}",flush=True); found.append(depth+rest)
    if found: break
    sc={t:w*(len(t[0])+len(t[1]))+math.log1p(abs(trK(t)+2))+random.random()*0.3 for t in cand}
    keys=sorted(cand,key=sc.get)[:K]; layers.append({t:cand[t] for t in keys}); fr=keys; seen.update(keys)
    if depth%8==0: print(f" d{depth} best wall-gap {min(math.log1p(abs(trK(t)+2)) for t in fr):.2f} {time.time()-t0:.0f}s",flush=True)
print("end",found,flush=True)
