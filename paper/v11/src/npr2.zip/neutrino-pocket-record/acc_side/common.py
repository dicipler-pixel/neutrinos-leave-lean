import os
def red(w):
    o=[]
    for c in w:
        if o and o[-1]==c.swapcase(): o.pop()
        else: o.append(c)
    return ''.join(o)
def inv(w): return w.swapcase()[::-1]
G='xXyY'
def move(R,m):
    a,b=R
    if m==0: return (inv(a),b)
    if m==1: return (a,inv(b))
    if m==2: return (red(a+b),b)
    if m==3: return (red(a+inv(b)),b)
    if m==4: return (a,red(b+a))
    if m==5: return (a,red(b+inv(a)))
    if m<=9: g=G[m-6]; return (red(g+a+g.swapcase()),b)
    g=G[m-10]; return (a,red(g+b+g.swapcase()))
INV=[0,1,3,2,5,4,7,6,9,8,11,10,13,12]
enc=lambda L:''.join({1:'x',-1:'X',2:'y',-2:'Y'}[v] for v in L)
def run(R,p):
    S=[R]
    for m in p: R=move(R,m); S.append(R)
    return S
