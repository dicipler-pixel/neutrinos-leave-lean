import os
import json,sys,time,random
from common import *
from shorten import bfs
row=sys.argv[1]; RB=int(sys.argv[2]); K=int(sys.argv[3]); cap=int(sys.argv[4]); target=int(sys.argv[5]); seed=int(sys.argv[6]) if len(sys.argv)>6 else 0
random.seed(seed)
d=json.load(open('rows.json'))[row]; start=tuple(d['start'])
t0=time.time(); T=bfs(('x','y'),RB,cap); print(f"ball {len(T)} {time.time()-t0:.0f}s",flush=True)
layers=[{start:None}]; fr=[start]; seen=set([start])
for depth in range(1,target-0):
    cand={}
    for s in fr:
        for m in range(14):
            t=move(s,m)
            if t in seen or t in cand or len(t[0])+len(t[1])>cap: continue
            cand[t]=(s,m)
    hit=[(T[t],t) for t in cand if t in T and depth+T[t]<target]
    if hit:
        v,t=min(hit); seq=[];x=t; L=layers+[cand]; k=len(L)-1
        while L[k][x]: x,mm=L[k][x]; seq.append(mm); k-=1
        print(f"HIT depth {depth} + {v} = {depth+v}: prefix {seq[::-1]} state {t}",flush=True); break
    # score: total length with random tiebreak; keep K
    keys=sorted(cand,key=lambda t:(len(t[0])+len(t[1])+random.random()*0.9))[:K]
    layers.append({t:cand[t] for t in keys}); fr=keys; seen.update(keys)
    if depth%4==0: print(f" depth {depth}: {len(cand)} cand, best len {len(fr[0][0])+len(fr[0][1]) if fr else None}, {time.time()-t0:.0f}s",flush=True)
    if not fr: break
