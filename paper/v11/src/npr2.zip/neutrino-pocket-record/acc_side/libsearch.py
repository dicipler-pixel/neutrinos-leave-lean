import os
import json,sys,pickle,time
from common import *
from shorten import bfs
lib=pickle.load(open('lib.pkl','rb'))
def smap(sw,sx,sy):
    def f(w):
        o=[]
        for c in w:
            base=c.lower(); neg=c.isupper()
            if base=='x': nb,s='y' if sw else 'x',sx
            else: nb,s='x' if sw else 'y',sy
            if s<0: neg=not neg
            o.append(nb.upper() if neg else nb)
        return ''.join(o)
    return f
SYM=[]
for sw in (0,1):
    for sx in (1,-1):
        for sy in (1,-1):
            f=smap(sw,sx,sy); cost=(sx<0)+(sy<0)
            SYM.append((sw,f,cost))
big={}
for s,(r,rid,i,p) in lib.items():
    for sw,f,c in SYM:
        t=(f(s[1]),f(s[0])) if sw else (f(s[0]),f(s[1]))
        v=r+c
        if t not in big or big[t][0]>v: big[t]=(v,rid,i,sw,c)
print("sym library",len(big),flush=True)
row=sys.argv[1]; R=int(sys.argv[2]); capx=int(sys.argv[3])
d=json.load(open('rows.json'))[row]; start=tuple(d['start']); road=d['road']
S=run(start,road); cap=max(len(a)+len(b) for a,b in S)+capx
best=(len(road),None)
# from the start, and from every state of our road
for i in range(len(road)):
    F=bfs(S[i],R if i==0 else max(3,R-2),cap)
    for s,dd in F.items():
        if s in big and i+dd+big[s][0]<best[0]: best=(i+dd+big[s][0],(i,s,dd,big[s]))
    if i==0: print(" start ball",len(F),"best",best[0],flush=True)
print(row,"best total",best[0],"vs road",len(road),best[1] and best[1][3][:2],flush=True)
