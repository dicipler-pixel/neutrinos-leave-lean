# SCRIPT: MOMENTUM-LIFTS-VALLEY-01  H = (p_x^2 + p_y^2)/2 + g x^2 y^2 / 2 : classical valleys along both axes are flat (V=0),
# yet the spectrum is discrete with a positive gap (Simon 1983). Checked by a growing grid: the low levels converge.
import numpy as np, scipy.sparse as sp, scipy.sparse.linalg as sl
for L,N in [(10,140),(14,200),(18,260)]:
    x=np.linspace(-L,L,N); h=x[1]-x[0]
    D2=sp.diags([1,-2,1],[-1,0,1],shape=(N,N))/h**2; I=sp.eye(N)
    T=-0.5*(sp.kron(D2,I)+sp.kron(I,D2)); X,Y=np.meshgrid(x,x,indexing='ij')
    H=T+sp.diags((0.5*X**2*Y**2).ravel())
    e=np.sort(sl.eigsh(H,k=4,sigma=0,which='LM',return_eigenvectors=False))
    print(f"box ±{L}, grid {N}: E0={e[0]:.4f} E1={e[1]:.4f} gap={e[1]-e[0]:.4f}")
# valley picture: at distance |x| along the y=0 valley the transverse y-mode is an oscillator with frequency |x| -> zero-point |x|/2
print("effective valley potential from transverse zero-point motion: V_eff(x) = |x|/2  (grows: the valley is closed)")
