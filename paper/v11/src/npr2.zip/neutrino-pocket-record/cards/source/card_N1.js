// CARD N1 — The wall: two equal perpendicular steps turn parabolic at z = 3+2√2 (Γ² = ½); the neutrino step sits on it.
// Every number is computed here from the formulas; nothing is drawn by hand. Deterministic in the loop phase p.
(function () {
  const RW = Math.log(3 + 2 * Math.SQRT2), R0 = 0.75, R1 = 2.35;
  const ease = p => { const q = Math.min(1, Math.max(0, (p - 0.06) / 0.86)); return q * q * (3 - 2 * q); };
  const rOf = p => R0 + (R1 - R0) * ease(p);
  const trK = r => 2 - 4 * Math.pow(Math.sinh(r / 2), 4);
  const kind = r => { const t = trK(r); return Math.abs(t + 2) < 0.02 ? 'ON THE WALL: parabolic' : (t > -2 ? 'inside: a closed turn' : 'past the wall: a climb'); };
  // Lorentz boosts on the hyperboloid (t,x,y,z); rapidity r (same r as the SL(2,C) boost cosh(r/2)+sinh(r/2)σ)
  const boost = (ax, r) => { const c = Math.cosh(r), s = Math.sinh(r), M = [[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]];
    M[0][0] = c; M[0][ax] = s; M[ax][0] = s; M[ax][ax] = c; return M; };
  const mul = (A, B) => A.map((row, i) => B[0].map((_, j) => row.reduce((a, _, k) => a + A[i][k] * B[k][j], 0)));
  const act = (M, v) => M.map(row => row.reduce((a, m, k) => a + m * v[k], 0));
  const toBall = v => [v[1] / (1 + v[0]), v[2] / (1 + v[0]), v[3] / (1 + v[0])];
  const O = [1, 0, 0, 0];
  const NL = 7, NS = 40; // loops drawn, samples per step
  function loopPath(r) {           // the square of steps x, y, x⁻¹, y⁻¹, repeated NL times, as points in the ball
    const pts = []; let P = [[1,0,0,0],[0,1,0,0],[0,0,1,0],[0,0,0,1]];
    const steps = [[1, r], [2, r], [1, -r], [2, -r]];
    for (let L = 0; L < NL; L++) for (const [ax, rr] of steps) {
      for (let s = 1; s <= NS; s++) pts.push(toBall(act(mul(P, boost(ax, rr * s / NS)), O)));
      P = mul(P, boost(ax, rr));
    }
    return pts;
  }
  function orbitDist(r, N) { const K = mul(mul(boost(1, r), boost(2, r)), mul(boost(1, -r), boost(2, -r))); let v = O.slice(); const d = [0];
    for (let n = 1; n <= N; n++) { v = act(K, v); d.push(Math.acosh(Math.max(1, v[0]))); } return d; }
  const STEPS = [['ν: m₃/m₂ (m₁=0)', 5.8165, '#7fffd4'], ['μ→τ', 16.82, '#ffbf4d'], ['d→s', 19.89, '#ffbf4d'], ['s→b', 44.74, '#ffbf4d'],
    ['c→t', 135.6, '#ffbf4d'], ['e→μ', 206.8, '#ffbf4d'], ['u→c', 589.4, '#ffbf4d']];
  const gam = z => (z - 1) / (z + 1);
  let line, lineGeo, dots, dotsGeo, rim, startDot, ends = [], tube = null, tubeMat, sceneRef;
  const NP = NL * 4 * NS;
  window.CARD = {
    title: 'Two equal steps. One wall. Where the neutrinos sit.',
    sub: 'Square of perpendicular boosts x, y, x⁻¹, y⁻¹ in the ball of velocities — computed, not drawn',
    mainLabel: 'Seven laps of the square, from the centre of the ball',
    caption: 'inside the wall the laps close into a turn · on the wall they drift to the rim · past it they run',
    setup3D(scene, camera) {
      sceneRef = scene;
      scene.add(new THREE.AmbientLight(0x404050, 1.2)); const kl = new THREE.DirectionalLight(0xffffff, 2.2); kl.position.set(3, 4, 5); scene.add(kl); const bl = new THREE.PointLight(0x6fb7ff, 30, 10); bl.position.set(-2, -2, 2); scene.add(bl);
      tubeMat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.35, metalness: 0.25, emissive: 0x111111 });
      rim = new THREE.Mesh(new THREE.SphereGeometry(1, 64, 48), new THREE.MeshBasicMaterial({ color: 0x2a3a55, wireframe: true, transparent: true, opacity: 0.10 }));
      scene.add(rim);
      const shell = new THREE.Mesh(new THREE.SphereGeometry(1, 96, 64), new THREE.ShaderMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.BackSide,
        vertexShader: 'varying vec3 vN; varying vec3 vW; void main(){ vN=normalize(normalMatrix*normal); vec4 w=modelViewMatrix*vec4(position,1.0); vW=-w.xyz; gl_Position=projectionMatrix*w; }',
        fragmentShader: 'varying vec3 vN; varying vec3 vW; void main(){ float r=pow(1.0-abs(dot(normalize(vN),normalize(vW))),2.5); gl_FragColor=vec4(vec3(0.25,0.45,0.9)*r*0.5,1.0); }' }));
      scene.add(shell);
      lineGeo = new THREE.BufferGeometry(); lineGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(NP * 3), 3));
      lineGeo.setAttribute('color', new THREE.BufferAttribute(new Float32Array(NP * 3), 3));
      line = new THREE.Line(lineGeo, new THREE.LineBasicMaterial({ vertexColors: true, transparent: true, opacity: 0.95, blending: THREE.AdditiveBlending }));
      scene.add(line);
      dotsGeo = new THREE.BufferGeometry(); dotsGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(NP * 3), 3));
      dotsGeo.setAttribute('color', new THREE.BufferAttribute(new Float32Array(NP * 3), 3));
      dots = new THREE.Points(dotsGeo, new THREE.PointsMaterial({ size: 0.075, map: G3.glowTex(), vertexColors: true, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }));
      scene.add(dots);
      startDot = new THREE.Sprite(new THREE.SpriteMaterial({ map: G3.glowTex(), color: 0xffffff, blending: THREE.AdditiveBlending, transparent: true, depthWrite: false }));
      startDot.scale.setScalar(0.18); scene.add(startDot);
      for (let L = 0; L < NL; L++) { const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: G3.glowTex(), blending: THREE.AdditiveBlending, transparent: true, depthWrite: false })); sp.scale.setScalar(0.16); ends.push(sp); scene.add(sp); }
      for (const [ax, col] of [[[1, 0, 0], 0xff8c3c], [[0, 1, 0], 0x7fdcff]]) {
        const g = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, 0, 0), new THREE.Vector3(...ax).multiplyScalar(1.08)]);
        scene.add(new THREE.Line(g, new THREE.LineBasicMaterial({ color: col, transparent: true, opacity: 0.55 })));
      }
    },
    update3D(p, scene, camera) {
      const r = rOf(p), pts = loopPath(r), pos = lineGeo.attributes.position.array, col = lineGeo.attributes.color.array;
      const dp = dotsGeo.attributes.position.array, dc = dotsGeo.attributes.color.array, c = new THREE.Color();
      const reveal = 1;
      for (let i = 0; i < NP; i++) { const q = pts[i], f = i / NP, on = f <= reveal ? 1 : 0.12;
        pos.set(q, 3 * i); dp.set(q, 3 * i);
        c.setHSL((0.62 - 0.62 * f + 1) % 1, 0.9, 0.55); col.set([c.r * on, c.g * on, c.b * on], 3 * i);
        const a = (i % NS === 0 ? 1.0 : 0.55) * on; dc.set([c.r * a, c.g * a, c.b * a], 3 * i); }
      lineGeo.attributes.position.needsUpdate = lineGeo.attributes.color.needsUpdate = true;
      if (tube) { sceneRef.remove(tube); tube.geometry.dispose(); }
      const cv = new THREE.CatmullRomCurve3(pts.map(q => new THREE.Vector3(...q)));
      const tg = new THREE.TubeGeometry(cv, 900, 0.018, 8, false); const n = tg.attributes.position.count, tc = new Float32Array(n * 3), cc2 = new THREE.Color();
      for (let i = 0; i < n; i++) { const f = Math.floor(i / 9) / 901; cc2.setHSL((0.62 - 0.62 * f + 1) % 1, 0.85, 0.55); tc.set([cc2.r, cc2.g, cc2.b], 3 * i); }
      tg.setAttribute('color', new THREE.BufferAttribute(tc, 3)); tube = new THREE.Mesh(tg, tubeMat); sceneRef.add(tube); line.visible = false;
      dotsGeo.attributes.position.needsUpdate = dotsGeo.attributes.color.needsUpdate = true;
      for (let L = 0; L < NL; L++) { const q = pts[(L + 1) * 4 * NS - 1]; ends[L].position.set(...q); const cc = new THREE.Color(); cc.setHSL((0.62 - 0.62 * (L + 1) / NL + 1) % 1, 0.9, 0.62); ends[L].material.color = cc; }
      G3.orbit(camera, p, 3.35, 28, 0.9);
    },
    left(p) { const r = rOf(p), z = Math.exp(r), t = trK(r);
      return [{ label: 'step ratio  z = e^r', value: [`z = ${z.toFixed(4)}`], big: true },
        
        { label: 'rapidity  r', value: [r.toFixed(4)] },
        { label: 'Smith  Γ = tanh(r/2)', value: [`${Math.tanh(r / 2).toFixed(4)}`, `Γ² = ${Math.pow(Math.tanh(r / 2), 2).toFixed(4)}`] },
        { label: 'commutator trace', value: [`tr K = ${t.toFixed(3)}`] },
        { label: 'kind', value: [kind(r)], color: Math.abs(t + 2) < 0.02 ? '#7fffd4' : (t > -2 ? '#7fdcff' : '#ffbf4d') }, { gap: 6 },
        { label: 'the wall', value: ['z = 3+2√2 = 5.8284', 'Γ = 1/√2,  tr K = −2'], color: '#7fffd4' },
        { label: 'neutrinos (NuFIT 6.0)', value: ['m₃/m₂ = 5.8165 ± 0.079', '−0.15σ from the wall'], color: '#7fffd4' }]; },
    scale(p, X, Y) { H.text('colour = lap', X, Y, { size: 14, color: CC.mut }); H.text('first → last', X, Y + 19, { size: 14, color: CC.mut });
      for (let i = 0; i < 60; i++) { const c = new THREE.Color(); c.setHSL((0.62 - 0.62 * i / 60 + 1) % 1, 0.9, 0.55); H.ctx.fillStyle = `rgb(${c.r * 255 | 0},${c.g * 255 | 0},${c.b * 255 | 0})`; H.ctx.fillRect(X + 10, Y + 34 + i * 3, 26, 3); }
      H.text('orange axis: x', X, Y + 240, { size: 13, color: '#ff8c3c' }); H.text('blue axis: y', X, Y + 259, { size: 13, color: '#7fdcff' });
      H.text('sphere = rim', X, Y + 290, { size: 13, color: CC.mut }); H.text('(speed of light)', X, Y + 309, { size: 13, color: CC.dim }); },
    overlay() {},
    panels: [
      { title: 'tr K = 2 − 4 sinh⁴(r/2)', draw(ctx, X, Y, w, h, p) { const r = rOf(p);
        const F = H.frame(X, Y, w, h, { x0: 0.5, x1: 2.5, y0: -7, y1: 2.5, xt: [[1, '1'], [RW, 'ln(3+2√2)'], [2.5, '2.5']], yt: [[2, '2'], [-2, '−2'], [-6, '−6']], xl: 'rapidity r' });
        const xs = [], ys = []; for (let i = 0; i <= 200; i++) { const x = 0.5 + 2 * i / 200; xs.push(x); ys.push(trK(x)); }
        F.clip(); H.curve(xs, ys, F, { color: '#ffc850', width: 2.4, glow: 8 }); H.hline(F, -2, { color: '#7fffd4', label: 'parabolic wall', right: true, below: true }); F.unclip();
        H.vline(F, F.fx(RW), { color: '#2f6f5f' }); H.dot(F.fx(r), F.fy(trK(r)), { color: '#ffffff', r: 6 });
        H.text('turn', F.L + 8, F.T + 14, { size: 12, color: '#7fdcff' }); H.text('climb', F.R - 8, F.B - 8, { size: 12, color: '#ffbf4d', align: 'right' }); } },
      { title: 'Mass steps on the Smith line Γ', draw(ctx, X, Y, w, h, p) { const r = rOf(p);
        const F = H.frame(X, Y, w, h, { x0: 0.6, x1: 1.0, y0: 0, y1: STEPS.length + 1, xt: [[0.6, '0.6'], [1 / Math.SQRT2, '1/√2'], [0.9, '0.9'], [1.0, '1']], yt: [], xl: 'Γ = (z−1)/(z+1)' });
        H.vline(F, F.fx(1 / Math.SQRT2), { color: '#2f6f5f' });
        STEPS.forEach(([lab, z, col], i) => { const y = F.fy(STEPS.length - i); H.dot(F.fx(gam(z)), y, { color: col, r: 5 }); H.text(lab, F.fx(gam(z)) + (i ? -8 : 9), y + 4, { size: 11, color: col, align: i ? 'right' : 'left' }); });
        const g = Math.tanh(r / 2); if (g > 0.6) { ctx.strokeStyle = '#ffffff'; ctx.setLineDash([3, 3]); ctx.beginPath(); ctx.moveTo(F.fx(g), F.T); ctx.lineTo(F.fx(g), F.B); ctx.stroke(); ctx.setLineDash([]); }
        H.text('charged: all past the wall', F.R - 6, F.B - 8, { size: 11, color: '#ffbf4d', align: 'right' }); } },
      { title: 'Distance of the n-th lap end from centre', draw(ctx, X, Y, w, h, p) { const r = rOf(p), N = 30, d = orbitDist(r, N);
        const F = H.frame(X, Y, w, h, { x0: 0, x1: N, y0: 0, y1: 30, xt: [[0, '0'], [10, '10'], [20, '20'], [30, '30']], yt: [[0, '0'], [10, '10'], [20, '20'], [30, '30']], xl: 'lap n' });
        const xs = d.map((_, i) => i); F.clip(); H.curve(xs, d, F, { color: '#7fdcff', width: 2.2, glow: 6 }); F.unclip();
        H.text(trK(r) > -2 + 1e-3 ? 'bounded: the lap turns' : (trK(r) < -2 - 1e-3 ? 'linear: the lap runs' : '~ log n: drifting to the rim'), F.L + 8, F.T + 14, { size: 12, color: CC.fg });
        H.text(`d(${N}) = ${d[N].toFixed(2)}`, F.R - 6, F.B - 8, { size: 11, color: CC.mut, align: 'right' }); } },
    ],
    foot: ['Inset maths: B_x(r) = cosh(r/2) + sinh(r/2)σ_x, K = B_x B_y B_x⁻¹ B_y⁻¹ · tr K = 2 − 4 sinh⁴(r/2) = −2 ⇔ r = ln(3+2√2) ⇔ Γ² = ½ · ball point = (x,y,z)/(1+t)',
      'Neutrinos (m₁ = 0): m₃/m₂ = √(Δm²₃₁/Δm²₂₁) = 5.8165, NuFIT 6.0 · relation: Alikhanov 2026 · read here as the wall',
      'Card N1 · The Neutrinos at the Wall (draft 1, 14 Nov 2026) · Theorem 1 · every number computed in this card'],
  };
})();
