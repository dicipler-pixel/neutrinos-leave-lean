// CARD N3 — Momentum closes the valley. V = ½x²y² is flat along both axes (classically no floor); the quantum ground state
// stays bound because pinching the sideways motion costs momentum: zero-point |s|/2 at distance s down a valley (Simon 1983).
// Art grammar from Mona Tesla v5 (J. Beasley): epicycle orbits z(t)=Σa e^{i(2πft+p)}, tone s, 29-wave grain, Perron colour,
// and the fracture envelope M_κ(u) = e^{−u/κ}(√(4+u²)+u)/2 for the lightning along the valleys.
(function () {
  const D = DATA.N3, L = D.L, E0 = 0.5533, GAP = 0.6333;          // converged values (three grids, see N3 README)
  const PI_ = [1.0, 0.7734701736161192, 0.4275433878626076];        // Mona Tesla Perron leader
  const PH = [0.7, 2.1, 4.4, 1.3, 5.6, 3.3, 0.2, 2.9];              // Mona Tesla bolt phases
  const ease = p => { const q = Math.min(1, Math.max(0, (p - 0.06) / 0.86)); return q * q * (3 - 2 * q); };
  const sOf = p => 0.35 + 6.0 * ease(p);
  const V = (x, y) => 0.5 * x * x * y * y;
  const ht = v => 0.85 * (1 - Math.exp(-v / 2.5));                    // displayed height (valleys at 0)
  const grain = (X, Y) => { let e = 0; for (let j = 1; j <= 29; j++) e += Math.pow(0.9, j) * Math.cos(Math.pow(1.25, j) * (Math.cos(3 * j * j) * X + Math.sin(3 * j * j) * Y) + Math.cos(4 * j)); return e; };
  const perron = s => PI_.map(pv => Math.max(0, Math.min(1, pv * s + (1 - pv) * s * s * s)));
  const Mk = (u, k) => Math.exp(-u / k) * (Math.sqrt(4 + u * u) + u) / 2;
  const Gk = k => 0.5 * Math.exp(-Math.sqrt(k * k - 4) / k) * (k + Math.sqrt(k * k - 4));
  const SC = 1 / L * 1.8;                                            // world scale: x in [−L, L] -> [−1.8, 1.8]
  let probe, slice, sliceGeo, bolts = [], chains = [], sceneRef, cloud;
  const NB = 901, ZS = 1.25, NE = 64;
  function chainPts(c, t) { let z = [0, 0]; const pts = [[0, 0]]; for (const [a, f, ph] of c) { const g = 2 * Math.PI * f * t + ph; z = [z[0] + a * Math.cos(g), z[1] + a * Math.sin(g)]; pts.push(z.slice()); } return pts; }
  window.CARD = {
    title: 'The valley is flat. The ground state still stays home.',
    sub: 'V = ½x²y²: zero energy all along both axes · momentum cost of pinching the sideways motion closes the valley',
    mainLabel: 'Landscape of V, the quantum cloud, and its outline drawn by epicycles',
    caption: 'white bead: free classical slide · gold: the quantum cloud |ψ₀|² · blue lightning: the leak that fades',
    setup3D(scene, camera) {
      sceneRef = scene;
      scene.add(new THREE.AmbientLight(0x50505a, 1.1)); const kl = new THREE.DirectionalLight(0xffffff, 2.0); kl.position.set(2, -3, 5); scene.add(kl);
      // surface coloured by the Mona Tesla tone, grain and Perron map
      const n = 180, g = new THREE.PlaneGeometry(3.6, 3.6, n, n), pos = g.attributes.position, col = new Float32Array(pos.count * 3);
      for (let i = 0; i < pos.count; i++) { const X = pos.getX(i) / SC, Y = pos.getY(i) / SC, v = V(X, Y); pos.setZ(i, ht(v));
        let s = 0.12 + 0.62 * (1 - Math.exp(-v / 3)); s = Math.max(0, Math.min(1, s + grain(X / 2.3, Y / 2.3) / 140)); col.set(perron(s), 3 * i); }
      g.setAttribute('color', new THREE.BufferAttribute(col, 3)); g.computeVertexNormals();
      scene.add(new THREE.Mesh(g, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.55, metalness: 0.15, side: THREE.DoubleSide })));
      // the quantum cloud: deterministic samples of |psi0|^2 on the 61x61 grid
      const r = G3.rng(20261115), cp = [], cc = [], M = D.grid.length;
      for (let k = 0; k < 30000; k++) { const i = Math.floor(r() * M), j = Math.floor(r() * M), w = D.grid[i][j]; if (r() > w) continue;
        const X = -L + 2 * L * (i + r() - 0.5) / (M - 1), Y = -L + 2 * L * (j + r() - 0.5) / (M - 1); cp.push(X * SC, Y * SC, ht(V(X, Y)) + 0.04 + 0.25 * w * r()); cc.push(1.0, 0.78, 0.35); }
      const cg = new THREE.BufferGeometry(); cg.setAttribute('position', new THREE.Float32BufferAttribute(cp, 3)); cg.setAttribute('color', new THREE.Float32BufferAttribute(cc, 3));
      cloud = new THREE.Points(cg, new THREE.PointsMaterial({ size: 0.08, map: G3.glowTex(), vertexColors: true, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending, depthWrite: false })); scene.add(cloud);
      // lightning along the four valleys, Mona Tesla offsets and fracture envelope
      for (const [dx, dy, k] of [[1, 0, 3.0], [-1, 0, 3.4], [0, 1, 3.8], [0, -1, 4.2]]) {
        const pts = [], cols = [];
        for (let q = 0; q < NB; q++) { const u = q / (NB - 1); let off = 0; for (let j = 0; j < 8; j++) off += 0.06 * Math.pow(0.62, j) * Math.sin(Math.pow(2, j) * Math.PI * u + PH[j]); off *= Math.sin(Math.PI * u);
          const d = 0.12 + 1.6 * u, X = dx * d - dy * off, Y = dy * d + dx * off; pts.push(X, Y, 0.03);
          const b = Mk(6 * (0.0 + 0.5 * u), k) / Gk(Math.max(k, 3)); cols.push(0.75 * b, 0.9 * b, 1.0 * b); }
        const bg = new THREE.BufferGeometry(); bg.setAttribute('position', new THREE.Float32BufferAttribute(pts, 3)); bg.setAttribute('color', new THREE.Float32BufferAttribute(cols, 3));
        const ln = new THREE.Line(bg, new THREE.LineBasicMaterial({ vertexColors: true, transparent: true, blending: THREE.AdditiveBlending })); bolts.push(ln); scene.add(ln); }
      // epicycle chains for three outlines of |psi0|^2, drawn on a floating plane
      const cols3 = [0xffc850, 0xff8c3c, 0x7fdcff]; let ci = 0;
      for (const lev of ['0.5', '0.12', '0.02']) { const coef = D.cont[lev], full = [];
        for (let r2 = 0; r2 <= 512; r2++) { const p_ = chainPts(coef, r2 / 512); const e = p_[p_.length - 1]; full.push(new THREE.Vector3(e[0] * SC, e[1] * SC, ZS)); }
        const trace = new THREE.Line(new THREE.BufferGeometry().setFromPoints(full), new THREE.LineBasicMaterial({ color: cols3[ci], transparent: true, opacity: 0.9 }));
        const arm = new THREE.Line(new THREE.BufferGeometry().setFromPoints(Array.from({ length: NE + 1 }, () => new THREE.Vector3())), new THREE.LineBasicMaterial({ color: 0xbfbfbf, transparent: true, opacity: 0.55 }));
        scene.add(trace, arm); chains.push({ coef, trace, arm }); ci++; }
      probe = new THREE.Mesh(new THREE.SphereGeometry(0.07, 32, 24), new THREE.MeshStandardMaterial({ color: 0xffffff, metalness: 0.6, roughness: 0.2, emissive: 0x333333 })); scene.add(probe);
      sliceGeo = new THREE.BufferGeometry(); sliceGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(201 * 3), 3));
      slice = new THREE.Line(sliceGeo, new THREE.LineBasicMaterial({ color: 0x7fffd4 })); scene.add(slice);
    },
    update3D(p, scene, camera) {
      const s = sOf(p), t = ease(p);
      probe.position.set(s * SC, 0, 0.08);
      const a = sliceGeo.attributes.position.array;                     // zero-point profile across the valley at x = s
      for (let i = 0; i <= 200; i++) { const y = -2.5 + 5 * i / 200, f = Math.exp(-s * y * y); a.set([s * SC, y * SC, ht(V(s, y)) + 0.05 + 0.6 * f], 3 * i); }
      sliceGeo.attributes.position.needsUpdate = true;
      for (const c of chains) { const n = Math.max(2, Math.floor(512 * t)); c.trace.geometry.setDrawRange(0, n);
        const pts = chainPts(c.coef, t); const arr = c.arm.geometry.attributes.position.array; pts.forEach((q, i) => arr.set([q[0] * SC, q[1] * SC, ZS], 3 * i)); c.arm.geometry.attributes.position.needsUpdate = true; }
      G3.orbit(camera, p, 6.3, 50, 0.6); camera.lookAt(0, 0, 0.35);
    },
    left(p) { const s = sOf(p);
      return [{ label: 'distance down the valley', value: [`s = ${s.toFixed(2)}`], big: true },
        { label: 'classical energy there', value: ['V(s, 0) = 0'] },
        { label: 'momentum (zero-point) cost', value: [`ħω/2 = s/2 = ${(s / 2).toFixed(3)}`], color: '#7fffd4' },
        { label: 'sideways width  Δy', value: [`1/√(2s) = ${(1 / Math.sqrt(2 * s)).toFixed(3)}`] },
        { label: 'sideways momentum  Δp', value: [`√(s/2) = ${Math.sqrt(s / 2).toFixed(3)}`, 'Δy·Δp = ½'] }, { gap: 6 },
        { label: 'ground energy (converged)', value: [`E₀ = ${E0}`], color: '#ffc850' },
        { label: 'gap above it', value: [`E₁ − E₀ = ${GAP}`], color: '#ffc850' },
        { label: 'classically', value: ['spectrum from 0, no gap'] }]; },
    scale(p, X, Y) { H.text('surface colour:', X, Y, { size: 13, color: CC.mut }); H.text('Mona Tesla tone', X, Y + 18, { size: 13, color: CC.mut }); H.text('+ grain + Perron', X, Y + 36, { size: 13, color: CC.mut });
      for (let i = 0; i < 60; i++) { const c = perron(0.12 + 0.62 * i / 60); H.ctx.fillStyle = `rgb(${c[0] * 255 | 0},${c[1] * 255 | 0},${c[2] * 255 | 0})`; H.ctx.fillRect(X + 10, Y + 50 + (59 - i) * 3, 26, 3); }
      H.text('high V', X + 42, Y + 58, { size: 11, color: CC.dim }); H.text('valley', X + 42, Y + 228, { size: 11, color: CC.dim });
      H.text('floating outlines:', X, Y + 262, { size: 13, color: CC.mut }); H.text('|ψ₀|² = ½, 0.12, 0.02', X, Y + 280, { size: 12, color: '#ffc850' }); H.text('64 epicycles each', X, Y + 298, { size: 12, color: CC.dim }); },
    overlay() {},
    panels: [
      { title: 'Energy ladder: quantum vs classical', draw(ctx, X, Y, w, h, p) {
        const F = H.frame(X, Y, w, h, { x0: 0, x1: 1, y0: 0, y1: 2.6, xt: [], yt: [[0, '0'], [0.5533, 'E₀'], [1.1866, 'E₁'], [2, '2']], xl: 'left: classical (any energy ≥ 0) · right: quantum levels' });
        ctx.fillStyle = 'rgba(160,160,160,0.18)'; ctx.fillRect(F.fx(0.05), F.fy(2.6), F.fx(0.4) - F.fx(0.05), F.fy(0) - F.fy(2.6));
        H.text('continuous', F.fx(0.22), F.fy(1.3), { size: 12, color: CC.mut, align: 'center' });
        D.E.forEach((e, i) => { ctx.strokeStyle = i === 0 ? '#ffc850' : '#cfcfcf'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(F.fx(0.55), F.fy(e)); ctx.lineTo(F.fx(0.95), F.fy(e)); ctx.stroke(); });
        ctx.strokeStyle = '#7fffd4'; ctx.beginPath(); ctx.moveTo(F.fx(0.75), F.fy(D.E[0])); ctx.lineTo(F.fx(0.75), F.fy(D.E[1])); ctx.stroke();
        H.text('gap 0.633', F.fx(0.77), F.fy((D.E[0] + D.E[1]) / 2), { size: 12, color: '#7fffd4' }); } },
      { title: 'Floor along the valley (y = 0)', draw(ctx, X, Y, w, h, p) { const s = sOf(p);
        const F = H.frame(X, Y, w, h, { x0: 0, x1: 6.5, y0: 0, y1: 3.4, xt: [[0, '0'], [2, '2'], [4, '4'], [6, '6']], yt: [[0, '0'], [1, '1'], [2, '2'], [3, '3']], xl: 'distance s down the valley' });
        H.curve([0, 6.5], [0.01, 0.01], F, { color: '#9a9a9a', width: 2 }); H.text('classical floor V = 0', F.R - 6, F.fy(0) - 6, { size: 11, color: '#9a9a9a', align: 'right' });
        const xs = [], ys = []; for (let i = 0; i <= 100; i++) { const x = 6.5 * i / 100; xs.push(x); ys.push(x / 2); }
        H.curve(xs, ys, F, { color: '#7fffd4', width: 2.4, glow: 8 }); H.hline(F, E0, { color: '#ffc850', label: 'E₀' });
        H.dot(F.fx(s), F.fy(s / 2), { color: '#ffffff', r: 6 }); H.text('momentum floor s/2', F.L + 8, F.T + 12, { size: 11, color: '#7fffd4' }); } },
      { title: 'Across the valley at distance s', draw(ctx, X, Y, w, h, p) { const s = sOf(p);
        const F = H.frame(X, Y, w, h, { x0: -2.5, x1: 2.5, y0: 0, y1: 1.6, xt: [[-2, '−2'], [0, '0'], [2, '2']], yt: [[0, '0'], [1, '1']], xl: 'sideways y' });
        const ys = [], v = [], g = []; for (let i = 0; i <= 200; i++) { const y = -2.5 + 5 * i / 200; ys.push(y); v.push(Math.min(1.6, 0.5 * s * s * y * y)); g.push(Math.exp(-s * y * y)); }
        F.clip(); H.curve(ys, v, F, { color: '#ff8c3c', width: 2 }); H.curve(ys, g, F, { color: '#7fffd4', width: 2.4, glow: 6 }); F.unclip();
        H.text('½s²y² (orange) pinches', F.L + 6, F.T + 12, { size: 11, color: '#ff8c3c' }); H.text('zero-point |φ|² (green) narrows', F.L + 6, F.T + 27, { size: 11, color: '#7fffd4' }); } },
    ],
    foot: ['Inset maths: H = ½(p_x²+p_y²) + ½x²y² · sideways oscillator of frequency |s| ⇒ floor |s|/2 · E₀ = 0.5533, gap 0.6333 (three grids)',
      'Discrete spectrum despite flat valleys: B. Simon 1983 · same mechanism in small-volume Yang–Mills: Lüscher 1983',
      'Card N3 · art grammar of Mona Tesla v5: epicycles, tone, grain, Perron colour, fracture envelope · every number computed'],
  };
})();
