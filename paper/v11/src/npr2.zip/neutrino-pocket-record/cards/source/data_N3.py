# SCRIPT: N3-DATA  quantum ground state of H = (px^2+py^2)/2 + x^2 y^2/2 on a grid; levels; level-set contours of |psi0|^2
# turned into Fourier epicycle chains (Mona Tesla grammar: z(t) = sum a_k e^{i(2 pi f_k t + p_k)}, 64 terms).
import numpy as np, scipy.sparse as sp, scipy.sparse.linalg as sl, json
L,N=7.0,181; x=np.linspace(-L,L,N); h=x[1]-x[0]
D2=sp.diags([1.,-2.,1.],[-1,0,1],shape=(N,N))/h**2; I=sp.eye(N); X,Y=np.meshgrid(x,x,indexing='ij')
H=-0.5*(sp.kron(D2,I)+sp.kron(I,D2))+sp.diags((0.5*X**2*Y**2).ravel())
w,v=sl.eigsh(H,k=8,sigma=0,which='LM'); o=np.argsort(w); w=w[o]; v=v[:,o]
psi=v[:,0].reshape(N,N); psi*=np.sign(psi[N//2,N//2]); rho=psi**2/np.max(psi**2)
# coarse density grid for the card (61x61)
idx=np.linspace(0,N-1,61).astype(int); rc=rho[np.ix_(idx,idx)]
# level-set contours by marching along rays (star-shaped: four-armed)
def contour(level,M=2048):
    th=np.linspace(0,2*np.pi,M,endpoint=False); pts=[]
    from scipy.interpolate import RegularGridInterpolator
    f=RegularGridInterpolator((x,x),rho)
    for t in th:
        rs=np.linspace(0,L*0.98,700); vals=f(np.c_[rs*np.cos(t),rs*np.sin(t)])
        k=np.argmax(vals<level) if np.any(vals<level) else len(rs)-1
        pts.append(rs[k]*np.exp(1j*t))
    z=np.array(pts); c=np.fft.fft(z)/M; f_=np.fft.fftfreq(M,1/M)
    keep=np.argsort(-np.abs(c))[:64]
    return [[float(abs(c[k])),float(f_[k]),float(np.angle(c[k]))] for k in keep]
cont={str(l):contour(l) for l in [0.5,0.12,0.02]}
# transverse oscillator at distance s along the valley: frequency |s|, zero-point |s|/2
json.dump({'E':[float(e) for e in w],'grid':rc.round(5).tolist(),'L':L,'cont':cont},open('data_N3.json','w'))
print('levels',np.round(w,4),'gap',round(w[1]-w[0],4))
