// CARD N2 — The radiation era is a fold: a(η) = η is odd and smooth; cosmic time t = η²/2 is even. The even observer sees a
// beginning; the signed coordinate passes through to the mirror. What crosses: the ledger (even) and the orientation (Z2).
(function () {
  const E = 1.4;
  const ease = p => { const q = Math.min(1, Math.max(0, (p - 0.06) / 0.86)); return q * q * (3 - 2 * q); };
  const eta = p => -E + 2 * E * ease(p);
  let curve, cgeo, walker, shadowT, shadowEta, sheet, mirror;
  const NC = 400;
  window.CARD = {
    title: 'No first moment: the radiation era is a fold',
    sub: 'Scale factor a = η (signed, smooth) · cosmic time t = η²/2 (even) · fold theorem of Beyond the Event Horizon',
    mainLabel: 'The path in (η, t, a): one smooth line, two shadows',
    caption: 'grey wall (t, a): what an even observer records — a beginning · floor (η, a): the same path, straight through',
    setup3D(scene, camera) {
      scene.add(new THREE.AmbientLight(0x404050, 1.3)); const kl = new THREE.DirectionalLight(0xffffff, 2.4); kl.position.set(3, 5, 4); scene.add(kl);
      const bead = new THREE.Mesh(new THREE.SphereGeometry(0.11, 32, 24), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.2, metalness: 0.5, emissive: 0x333333 })); window.__bead = bead; scene.add(bead);
      const pts = []; for (let i = 0; i <= NC; i++) { const e = -E + 2 * E * i / NC; pts.push(new THREE.Vector3(e, e * e / 2, e)); }
      cgeo = new THREE.BufferGeometry().setFromPoints(pts);
      const col = new Float32Array((NC + 1) * 3); for (let i = 0; i <= NC; i++) { const c = new THREE.Color(); c.setHSL(i < NC / 2 ? 0.58 : 0.08, 0.9, 0.58); col.set([c.r, c.g, c.b], 3 * i); }
      cgeo.setAttribute('color', new THREE.BufferAttribute(col, 3));
      curve = new THREE.Line(cgeo, new THREE.LineBasicMaterial({ vertexColors: true })); scene.add(curve);
      for (const [a, b, c] of [[0, NC / 2 + 1, 0x6fb7ff], [NC / 2, NC + 1, 0xffb35a]]) scene.add(new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts.slice(a, b)), 300, 0.06, 16, false), new THREE.MeshStandardMaterial({ color: c, roughness: 0.3, metalness: 0.3, emissive: c, emissiveIntensity: 0.25 })));
      // shadows: on the (t,a) wall (η = -E-0.2) and on the (η,a) floor (t = -0.15)
      const sh1 = [], sh2 = []; for (let i = 0; i <= NC; i++) { const e = -E + 2 * E * i / NC; sh1.push(new THREE.Vector3(-E - 0.25, e * e / 2, e)); sh2.push(new THREE.Vector3(e, -0.15, e)); }
      scene.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(sh1), new THREE.LineBasicMaterial({ color: 0x9a9a9a })));
      scene.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(sh2), new THREE.LineBasicMaterial({ color: 0x7fffd4 })));
      const wall = new THREE.Mesh(new THREE.PlaneGeometry(1.25, 3.0), new THREE.MeshBasicMaterial({ color: 0x1a1a1a, side: THREE.DoubleSide, transparent: true, opacity: 0.55 }));
      wall.rotation.y = Math.PI / 2; wall.position.set(-E - 0.26, 0.5, 0); scene.add(wall);
      const floor = new THREE.Mesh(new THREE.PlaneGeometry(3.0, 3.0), new THREE.MeshBasicMaterial({ color: 0x0f1f1c, side: THREE.DoubleSide, transparent: true, opacity: 0.55 }));
      floor.rotation.x = Math.PI / 2; floor.position.set(0, -0.16, 0); scene.add(floor);
      // the fold line η = 0
      scene.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, -0.15, -1.5), new THREE.Vector3(0, -0.15, 1.5)]), new THREE.LineDashedMaterial({ color: 0x7fffd4 })));
      walker = new THREE.Sprite(new THREE.SpriteMaterial({ map: G3.glowTex(), color: 0xffffff, blending: THREE.AdditiveBlending, transparent: true, depthWrite: false })); walker.scale.setScalar(0.32); scene.add(walker);
      shadowT = new THREE.Sprite(new THREE.SpriteMaterial({ map: G3.glowTex(), color: 0xbbbbbb, blending: THREE.AdditiveBlending, transparent: true, depthWrite: false })); shadowT.scale.setScalar(0.22); scene.add(shadowT);
      shadowEta = new THREE.Sprite(new THREE.SpriteMaterial({ map: G3.glowTex(), color: 0x7fffd4, blending: THREE.AdditiveBlending, transparent: true, depthWrite: false })); shadowEta.scale.setScalar(0.22); scene.add(shadowEta);
    },
    update3D(p, scene, camera) { const e = eta(p);
      walker.position.set(e, e * e / 2, e); window.__bead.position.set(e, e * e / 2, e); shadowT.position.set(-E - 0.25, e * e / 2, e); shadowEta.position.set(e, -0.15, e);
      walker.material.color.setHSL(e < 0 ? 0.58 : 0.08, 0.9, 0.7);
      camera.up.set(0, 1, 0); const a = 0.4 + 2 * Math.PI * p; camera.position.set(5.6 * Math.sin(a), 2.6, 5.6 * Math.cos(a)); camera.lookAt(0, 0.35, 0); },
    left(p) { const e = eta(p), t = e * e / 2;
      return [{ label: 'signed coordinate', value: [`η = ${e >= 0 ? '+' : ''}${e.toFixed(3)}`], big: true }, 
        { label: 'scale factor  a = η', value: [`${e.toFixed(3)}  (odd, smooth)`] },
        { label: 'cosmic time  t = η²/2', value: [`${t.toFixed(4)}  (even)`] },
        { label: 'da/dt as the even observer sees it', value: [Math.abs(e) < 1e-3 ? '→ ∞ (looks like a beginning)' : `${(1 / e).toFixed(2)}`], color: Math.abs(e) < 0.12 ? '#ff8c6a' : CC.fg },
        { label: 'side', value: [e < 0 ? 'mirror sheet (before)' : 'this sheet (after)'], color: e < 0 ? '#6fb7ff' : '#ffb35a' }, { gap: 6 },
        { label: 'what crosses (survival principles)', value: ['ledger: even, unchanged', 'orientation: a ℤ₂ sign', 'odd readings cancel'], color: '#7fffd4' }]; },
    scale(p, X, Y) { H.text('blue: mirror sheet', X, Y, { size: 14, color: '#6fb7ff' }); H.text('orange: this sheet', X, Y + 20, { size: 14, color: '#ffb35a' });
      H.text('grey shadow:', X, Y + 60, { size: 13, color: CC.mut }); H.text('even observer', X, Y + 78, { size: 13, color: CC.mut });
      H.text('green shadow:', X, Y + 110, { size: 13, color: '#7fffd4' }); H.text('signed coordinate', X, Y + 128, { size: 13, color: '#7fffd4' }); },
    overlay() {},
    panels: [
      { title: 'Even observer: a against t', draw(ctx, X, Y, w, h, p) { const e = eta(p);
        const F = H.frame(X, Y, w, h, { x0: 0, x1: 1.0, y0: -1.45, y1: 1.45, xt: [[0, '0'], [0.5, '0.5'], [1, '1']], yt: [[-1, '−1'], [0, '0'], [1, '1']], xl: 't = η²/2' });
        const xs = [], yp = [], yn = []; for (let i = 0; i <= 200; i++) { const t = i / 200; xs.push(t); yp.push(Math.sqrt(2 * t)); yn.push(-Math.sqrt(2 * t)); }
        F.clip(); H.curve(xs, yp, F, { color: '#ffb35a', width: 2.2 }); H.curve(xs, yn, F, { color: '#6fb7ff', width: 2.2 }); F.unclip();
        H.dot(F.fx(e * e / 2), F.fy(e), { color: '#ffffff', r: 6 }); H.text('a = ±√(2t): a cusp at t = 0', F.L + 6, F.T + 12, { size: 11, color: CC.mut }); } },
      { title: 'Signed coordinate: a against η', draw(ctx, X, Y, w, h, p) { const e = eta(p);
        const F = H.frame(X, Y, w, h, { x0: -1.45, x1: 1.45, y0: -1.45, y1: 1.45, xt: [[-1, '−1'], [0, '0'], [1, '1']], yt: [[-1, '−1'], [0, '0'], [1, '1']], xl: 'η' });
        H.curve([-1.45, 0], [-1.45, 0], F, { color: '#6fb7ff', width: 2.2 }); H.curve([0, 1.45], [0, 1.45], F, { color: '#ffb35a', width: 2.2 });
        H.vline(F, F.fx(0), { color: '#2f6f5f' }); H.dot(F.fx(e), F.fy(e), { color: '#ffffff', r: 6 }); H.text('one straight line: nothing breaks', F.L + 6, F.T + 12, { size: 11, color: CC.mut }); } },
      { title: 'What passes through the fold', draw(ctx, X, Y, w, h, p) { const e = eta(p);
        ctx.fillStyle = CC.panel; ctx.fillRect(X, Y, w, h);
        const bars = [['ledger (even)', 0.72, '#7fffd4'], ['orientation sign', e >= 0 ? 0.5 : -0.5, e >= 0 ? '#ffb35a' : '#6fb7ff'], ['odd reading', 0.55 * Math.tanh(4 * e), '#ff8c6a']];
        const cy = Y + h / 2 + 6; ctx.strokeStyle = '#333'; ctx.beginPath(); ctx.moveTo(X + 10, cy); ctx.lineTo(X + w - 10, cy); ctx.stroke();
        bars.forEach(([lab, v, c], i) => { const bx = X + 30 + i * 105, bh = v * (h / 2 - 40); ctx.fillStyle = c; ctx.fillRect(bx, Math.min(cy, cy - bh), 60, Math.abs(bh)); H.text(lab, bx + 30, Y + h - 10, { size: 11, color: c, align: 'center' }); });
        H.text('ledger unchanged · sign kept by the cover', X + 8, Y + 16, { size: 11, color: CC.mut }); H.text('odd parts cancel across the mirror', X + 8, Y + 32, { size: 11, color: CC.mut }); } },
    ],
    foot: ['Inset maths: radiation Friedmann a″ = 0 ⇒ a = a₁η, dt = a dη ⇒ t = a₁η²/2 (Whitney fold A₂) · da/dt ∝ t^(−1/2) while a(η) is analytic and odd',
      'Fold normal form ds² = dX²/(4c²X), X = λ² (four-body wall c = 1, horizon base c = κ) · continuation: Boyle, Finn & Turok 2018',
      'Card N2 · The Neutrinos at the Wall (draft 1, 14 Nov 2026) · Section 6 · every number computed in this card'],
  };
})();
